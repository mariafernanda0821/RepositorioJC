from django.apps import AppConfig


class DeudaConfig(AppConfig):
    name = 'deuda'
