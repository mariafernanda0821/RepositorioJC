from django.apps import AppConfig


class EdificioConfig(AppConfig):
    name = 'edificio'
